//
//  ResultsF.swift
//  healthapp
//
//  Created by T04-09 on 24/7/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class ResultsF: UIViewController {
    
    var Bmif: String?
    var Caloriesf: String?
    
    @IBOutlet weak var caloriesf: UILabel!
    @IBOutlet weak var bmif: UILabel!
    
        override func viewDidLoad() {
              super.viewDidLoad()

              if let string = Bmif {
              bmif.text = string
          }
            if let string = Caloriesf {
                caloriesf.text = string
            }
    }

}
