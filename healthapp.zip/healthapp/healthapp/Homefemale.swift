//
//  Homefemale.swift
//  healthapp
//
//  Created by T04-09 on 4/8/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class Homefemale: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func Calories(_ sender: UIButton) {
        performSegue(withIdentifier: "CaloriesF", sender: self)
    }
    
    
    @IBAction func Bmi(_ sender: UIButton) {
        performSegue(withIdentifier: "FemaleToBmi", sender: self)
    }
    
    
    @IBAction func Both(_ sender: UIButton) {
        performSegue(withIdentifier: "CaloriesF", sender: self)
    }
    
}
