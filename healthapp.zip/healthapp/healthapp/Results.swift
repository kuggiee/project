//
//  Results.swift
//  healthapp
//
//  Created by T04-09 on 24/7/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class Results: UIViewController {

    var Bmi: String?
    var calorie: String?
    
    @IBOutlet weak var bmi: UILabel!
    @IBOutlet weak var Calorie: UILabel!
    
    override func viewDidLoad() {
          super.viewDidLoad()

          if let string = Bmi {
          bmi.text = string
      }
        if let string = calorie {
            Calorie.text = string
        }
}
}
