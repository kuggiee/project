//
//  Login.swift
//  healthapp
//
//  Created by T04-09 on 3/8/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class Login: UIViewController {


    @IBOutlet weak var Signup: UIButton!
    @IBOutlet weak var Login: UIButton!
    @IBOutlet weak var Label1: UILabel!
    var userInfo = UserDefaults.standard
    var username : String = ""
    var password : String = ""
    var alertController = UIAlertController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Signup.layer.cornerRadius = 15.0
        Login.layer.cornerRadius = 15.0
    }
override func
    didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    
    }
    
    @IBAction func Login(_ sender: UIButton) {
    alertController = UIAlertController(title: "Login", message: "Enter username and password", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {(ACTION: UIAlertAction) -> Void in print("Login has been cancelled")
        })
        let loginAction = UIAlertAction (title: "Login", style: .default, handler: {(ACTION: UIAlertAction) -> Void in
            guard let textFields = self.alertController.textFields else {print("No text fields on alert controller"); return}
            guard let usernameText = textFields[0].text else{
                print("No username entered"); return}
            guard let passwordText = textFields[1].text else {print("No password entered"); return}
            self.username = usernameText
            self.password = passwordText
            if let userInfo = (self.userInfo.dictionary(forKey: "info")){
                for (i,j) in userInfo{
                    if (i.uppercased()==self.username.uppercased()) && (j as! String==self.password){
                        print("Login successfully!")
                    self.performSegue(withIdentifier:"Login", sender: self);
                        return;
                    }
                }
                self.displayMessage()
                
            }else{
                self.displayMessage()
            }
            
        })
        

    alertController.addAction(cancelAction)
    alertController.addAction(loginAction)
    alertController.preferredAction = loginAction
    alertController.addTextField(configurationHandler: {(TEXTFIELD: UITextField) -> Void in
        TEXTFIELD.placeholder = "Username here"
        TEXTFIELD.autocapitalizationType = .sentences
    })
        alertController.addTextField(configurationHandler: {(TEXTFIELD: UITextField) -> Void in
            TEXTFIELD.placeholder = "Password here"
            TEXTFIELD.isSecureTextEntry = true
        })
        alertController.view.backgroundColor = UIColor.red
        present(alertController, animated: true, completion: {() -> Void in
            print ("User is tyring to login")
            })
}
        func displayMessage(){
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: {(timer) in
                let alertController = UIAlertController(title: "Username or Password Error!", message:
                "Incorrect Username or Password", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "Cancel", style: .default))
                self.Label1.isHidden = true
                self.Label1.text = ""

                self.present(alertController, animated: true, completion: nil)
            })
            self.Label1.text = ""
            self.Label1.isHidden = false
            self.alertController.dismiss(animated: true, completion: nil)
        }

    @IBAction func Signup(_ sender: UIButton){
        performSegue(withIdentifier: "SignUpVC", sender: nil)
    }
}

