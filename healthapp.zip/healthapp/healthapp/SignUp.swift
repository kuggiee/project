//
//  SignUp.swift
//  healthapp
//
//  Created by T04-09 on 3/8/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class SignUp: UIViewController {
    
    
    @IBOutlet weak var Signup: UIButton!
    @IBOutlet weak var usernameInput: UITextField!
       @IBOutlet weak var password1Input: UITextField!
       @IBOutlet weak var password2Input: UITextField!
    
       var userInfo = UserDefaults.standard
       
       override func viewDidLoad() {
       super.viewDidLoad()
          Signup.layer.cornerRadius = 15.0
       }
       
       @IBAction func registerBtn(_ sender: UIButton) {
           
           guard let usernameText = usernameInput.text, !usernameText.isEmpty else {
               print("No Username entered")
               return
           }
           guard let password1Text = password1Input.text, !password1Text.isEmpty else {
               print("No Password entered")
               return
           }
           guard let password2Text = password2Input.text, !password2Text.isEmpty else {
               print("No Password entered")
               return
           }
           
            if checkUsername(username: usernameText) && checkPassword(password1: password1Text, password2: password2Text) &&
                    isValidPassword(password1: password1Text){
                       userInfo.set([usernameText: password1Text], forKey: "info")
                       usernameInput.text?.removeAll()
                       password1Input.text?.removeAll()
                       password2Input.text?.removeAll()
                       print("Registration Succesfull")
                        self.performSegue(withIdentifier:"SignToLogin", sender: self);
                   }
                   
               }
            
            func isValidPassword(password1: String) -> Bool {
                
                let regex = ("^(?=.*[a-z])(?=.*[$@$#!%*?&])(?=.*[A-Z]).{8,}$")
                let password = NSPredicate(format: "SELF MATCHES %@", regex)
                if password.evaluate(with: password1) {
                    return true
                } else {
                    let alertController = UIAlertController(title: "Password Error!", message:
                      "Missing Uppercase or Lowercase, Special Character or at least 8 character long", preferredStyle: .alert)
                        alertController.addAction(UIAlertAction(title: "Cancel", style: .default))

                    self.present(alertController, animated: true, completion: nil)
                    
                    return false
                }
            }
       
       func checkUsername(username: String) -> Bool {
           if let userInfo = (self.userInfo.dictionary(forKey: "info")) {
               print(userInfo)
               for (i,_) in userInfo {
                   if i.uppercased() == username.uppercased() {
                       print(i.uppercased())
                       print(username)
                       print("Username taken")
                    let alertController = UIAlertController(title: "Username Error!", message:
                    "Username Taken", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Cancel", style: .default))

                    self.present(alertController, animated: true, completion: nil)
                       return false
                   } else {
                       return true
                   }
               }
           }
           return true
       }
       
       func checkPassword(password1: String, password2: String) -> Bool {
           if password1 != password2 {
               print("Password Error!")
            let alertController = UIAlertController(title: "Password Error!", message:
            "Password Don't Match", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Cancel", style: .default))

            self.present(alertController, animated: true, completion: nil)
               return false
           }
           return true
       }
}
