//
//  CaloriesF.swift
//  healthapp
//
//  Created by T04-09 on 24/7/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class CaloriesF: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
      }
      
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var pa: UILabel!
    @IBOutlet weak var height: UILabel!
    @IBOutlet weak var weight: UILabel!
    @IBOutlet weak var result: UILabel!
    

     
      var a:Float = 20
      var p:Float = 1.0
      var h:Float = 1
      var w:Float = 55
      var calories:Float = 0;
      
    @IBAction func ageValue(_ sender: UISlider) {
        a = round(sender.value)
        age.text = NSString (format: " %.2f ", a) as String
        
    }
    
    @IBAction func paValue(_ sender: UISlider) {
        p = sender.value
        pa.text = NSString (format: " %.2f ", p) as String
    }
    
    @IBAction func heightValue(_ sender: UISlider) {
         h = sender.value
         height.text = NSString (format: " %.2f m", h) as String
         
     }
     
     @IBAction func weightValue(_ sender: UISlider) {
          w = sender.value
          weight.text = NSString (format: " %.2f kg", w) as String
          
      }
      
    @IBAction func next(_ sender: UIButton) {
      if result.text != "" {
              performSegue(withIdentifier: "bmif", sender: self)
              }
          }
          
          override func prepare(for segue: UIStoryboardSegue, sender: Any?){
              let destination = segue.destination as! BMIF
              destination.calorief = result.text
          }
    
    @IBAction func CalcCalories(_ sender: Any) {
        calories = 387 - 7.31 * a + p * (10.9 * w + 660.7 * h)
          
        var str = ""
        str = String(calories)
        result.text = str
        }


}
