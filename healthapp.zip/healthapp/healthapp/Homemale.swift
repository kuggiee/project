//
//  Homemale.swift
//  healthapp
//
//  Created by T04-09 on 4/8/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class Homemale: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func Calories(_ sender: UIButton) {
        performSegue(withIdentifier: "Calories", sender: self)
    }
    
    
    @IBAction func Bmi(_ sender: UIButton) {
        performSegue(withIdentifier: "MaleToBmi", sender: self)
    }
    
    
    @IBAction func Both(_ sender: UIButton) {
        performSegue(withIdentifier: "Calories", sender: self)
    }
    
    
}
