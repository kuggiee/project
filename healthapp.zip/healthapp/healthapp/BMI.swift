//
//  BMI.swift
//  healthapp
//
//  Created by T04-09 on 24/7/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class BMI: UIViewController {

    var calorie: String?
    
    @IBOutlet weak var Calorie: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let string = calorie {
            Calorie.text = string
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    @IBOutlet weak var height: UILabel!
    @IBOutlet weak var weight: UILabel!
    @IBOutlet weak var result: UILabel!
    var h:Float = 1
    var w:Float = 55
    var bmi:Float = 0;
    
    @IBAction func heightValue(_ sender: UISlider) {
        h = sender.value
        height.text = NSString (format: " %.2f m", h) as String
        
    }
    
    
    @IBAction func weightValue(_ sender: UISlider) {
        w = sender.value
        weight.text = NSString (format: " %.2f kg", w) as String
        
    }
    
    @IBAction func next(_ sender: Any) {
        if result.text != "" , Calorie.text != ""{
        performSegue(withIdentifier: "result", sender: self)
    }
}
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?){
            let destination = segue.destination as! Results
            destination.Bmi = result.text
            destination.calorie = Calorie.text
        }
    @IBAction func calcBMI(_ sender: UIButton) {
        bmi = w / (h*h)
        
        var str = ""
        
        if bmi < 18.5
        {
            str = NSString(format: "%.2f, Underweight", bmi) as String
            result.backgroundColor = UIColor.orange
        } else if bmi >= 18.5 && bmi < 25
        {
            str = NSString(format: " %.2f, Normal Weight", bmi) as String
            result.backgroundColor = UIColor.green
        } else if bmi >= 25 && bmi < 30
        {
            str = NSString(format: "%.2f, Overweight", bmi) as String
            result.backgroundColor = UIColor.red
        } else
        {
            str = NSString(format: "%.2f, Mega Overweight", bmi) as String
            result.backgroundColor = #colorLiteral(red: 0.3741977811, green: 0.0820152238, blue: 0.07565488666, alpha: 1)
        }
        
        result.text = str 
    
}
}

