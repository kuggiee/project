//
//  Gender.swift
//  healthapp
//
//  Created by T04-09 on 4/8/20.
//  Copyright © 2020 T04-09. All rights reserved.
//

import UIKit

class Gender: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var outlet: UISegmentedControl!
    @IBAction func start(_ sender: UIButton) {
        switch outlet.selectedSegmentIndex {
        case 0:
            self.performSegue(withIdentifier:"Male", sender: self)
        case 1:
            self.performSegue(withIdentifier:"Female", sender: self);
        default:
            break
        }
    }
    


    
    
    
}
