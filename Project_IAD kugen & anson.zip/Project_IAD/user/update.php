<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Project IAD</title>
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=catamaran:100,200,300.400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
</head>

<body>
<div class="header">
	<header>
		<a href="../Index.html" class="header-brand">ITEfriendly</a>
		<div class="nav">
		<nav>
			<ul>
			<li><a href="../Index.html">Home</a></li>
			<li><a href="../Course.php">Course</a></li>
			<li><a href="registration.php">Student Application</a></li>
			</ul>
			<a href="admin_login.php" class="header-login">Login</a>
			</nav>
		</div>
	</header>
	</div>
	
<div class="article">
			<section class="banner">
				<div class="vertical-center">
				<h2>ITEfriendly web developer <br>course</h2>
				<h1>Innovate Training, a continous education and training company</h1>
					</div>
				</section>   
  

<form method="post" action="edit.php">
	<input type="hidden" name="id" value="<?php echo $gresult["id"]; ?>">
	<table>
		<tr>
			<td>Course Name: </td>
			<td><input type="text" name="course" value="<?php echo $gresult["course"]; ?>" id="course"></td>
		</tr>
		<tr>
			<td>Price: </td>
			<td><input type="number" name="price" value="<?php echo $gresult["price"]; ?>" id="price"></td>
		</tr>
		<tr>
			<td>Description: </td>
			<td><textarea rows="10" cols="30" name="description" id="description"><?php echo $gresult["description"]; ?></textarea></td>
		</tr>
		<tr>
			<td>Duration: </td>
			<td><input type="number" name="duration" value="<?php echo $gresult["duration"]; ?>" id="duration"></td>
		</tr>
		<tr>
			<td>Seats: </td>
			<td><input type="number" name="seats" value="<?php echo $gresult["seats"]; ?>" id="seats"></td>
		</tr>
	</table>
	<input type="hidden" name="action_type" value="edit">
	<input type="submit" name="save" id="save" value="Save">
</form>
<form method="post" action="view_user.php">
	<input type="submit" name="cancel" id="cancel" value="Cancel">
</form>

	<div class="aside">
				<div class="wrapper">
				<footer>
				<ul class="list">
					<li><a href="../Course.php">Course</a></li>
					<li><a href="registration.php">Student Application</a></li>
					<li><a href="https://www.youtube.com">Youtube</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are/get-in-touch">Contact Us</a></li>
				</ul>
					<li><p>👋</p></li>
				</footer>
</div>
</div>

</body>  
  
</html>