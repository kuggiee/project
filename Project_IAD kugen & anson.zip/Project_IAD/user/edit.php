<?php
include 'database.php';

$gresult = '';

if (isset($_POST['action']) and $_POST['action'] == 'edit') {
	$id = (isset($_POST["ci"]) ? $_POST["ci"] : '');
	$sql = "SELECT * FROM courses WHERE id = $id";
	$result = mysqli_query($link, $sql);
	$gresult = mysqli_fetch_array($result);
	include 'update.php';
	exit();
}

if (isset($_POST['action_type'])) {
	if ($_POST['action_type'] == 'add' or $_POST['action_type'] == 'edit') {
		// Sanitize the data and assign to variables
		$id = $_POST['id'];
		$course = $_POST['course'];
		$price = $_POST['price'];
		$description = $_POST['description'];
		$duration = $_POST['duration'];
		$seats = $_POST['seats'];

		if ($_POST['action_type'] == 'add') {
			$sql = "INSERT INTO courses SET 
					course = '$course', 
					price = '$price',
					description = '$description',
					duration = '$duration', 
					seats = '$seats'";
		} else {
			$sql = "UPDATE courses SET 
					course = '$course', 
					price = '$price', 
					description = '$description',
					duration = '$duration', 
					seats = '$seats'
					WHERE id = $id";
		}
		mysqli_query($link, $sql);
	}
	header ('Location: view_user.php');
	exit();
}
?>
	