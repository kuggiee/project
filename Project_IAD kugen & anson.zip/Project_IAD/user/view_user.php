<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Project IAD</title>
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=catamaran:100,200,300.400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
	
<?php 
include 'database.php';

// get data from db table
$sql = "SELECT * FROM courses";
$result = mysqli_query($link, $sql);

$sql = "SELECT * FROM student";
$sresult = mysqli_query($link, $sql);

//push retrieved data into reg-ist array row by row
while ($row = mysqli_fetch_array($result)) { 
	$reg_list[] = array('id' => $row['id'],
					   'course' => $row['course'],
					   'price' => $row['price'],
					   'description' => $row['description'],
					   'duration' => $row['duration'],
					   'seats' => $row['seats']);
}
	
while ($srow = mysqli_fetch_array($sresult)) { 
	$sreg_list[] = array('id' => $srow['id'],
					   'name' => $srow['name'],
					   'course' => $srow['course'],
					   'email' => $srow['email'],
					   'contact' => $srow['contact'],
					   'date' => $srow['date']);
}
?>
</head>
	

<body>
<div class="header">
	<header>
		<a href="../Index.html" class="header-brand">ITEfriendly</a>
		<div class="nav">
		<nav>
			<ul>
			<li><a href="../Index.html">Home</a></li>
			<li><a href="../Course.php">Course</a></li>
			<li><a href="registration.php">Student Application</a></li>
			</ul>
			<a href="admin_login.php" class="header-login">Login</a>
			</nav>
		</div>
	</header>
	</div>
	
<div class="article">
			<section class="banner">
				<div class="vertical-center">
				<h2>ITEfriendly web developer <br>course</h2>
				<h1>Innovate Training, a continous education and training company</h1>
					</div>
				</section>
	</div>
	<section class="table">
	<table>
		<tr>
			<th>ID</th>
			<th>Course name</th>
			<th>Price</th>
			<th>Description</th>
			<th>Duration</th>
			<th>Seats</th>
		</tr>
		<?php foreach($reg_list as $course) : ?>
		<tr>
			<td><?php echo $course["id"] ?></td>
			<td><?php echo $course["course"] ?></td>
			<td><?php echo $course["price"] ?></td>
			<td><?php echo $course["description"] ?></td>
			<td><?php echo $course["duration"] ?></td>
			<td><?php echo $course["seats"] ?></td>
			<td>
				<form method="post" action="edit.php">
					<input type="hidden" name="ci" value="<?php echo $course["id"] ?>">
					<input type="hidden" name="action" value="edit">
					<input type="submit" value="Edit">
				</form>
			</td>
			<td>
				<form method="post" action="delete.php">
					<input type="hidden" name="ci" value="<?php echo $course["id"] ?>">
					<input type="hidden" name="action" value="delete">
					<input type="submit" value="Delete">
				</form>
		</tr>
		<?php endforeach; ?>
				<br>
			<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Course</th>
			<th>Email</th>
			<th>Contact</th>
			<th>Date</th>
		</tr>
		<?php foreach($sreg_list as $students) : ?>
		<tr>
			
			<td><?php echo $students["id"] ?></td>
			<td><?php echo $students["name"] ?></td>
			<td><?php echo $students["course"] ?></td>
			<td><?php echo $students["email"] ?></td>
			<td><?php echo $students["contact"] ?></td>
			<td><?php echo $students["date"] ?></td>
			<td>
		</tr>	
	<?php endforeach; ?>
	</table>	
</section>
<a href="insert.php">Add New Course</a>	
	<h1><a href="logout.php">Logout here</a> </h1>

	<div class="aside">
				<div class="wrapper">
				<footer>
				<ul class="list">
					<li><a href="../Course.php">Course</a></li>
					<li><a href="registration.php">Student Application</a></li>
					<li><a href="https://www.youtube.com">Youtube</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are/get-in-touch">Contact Us</a></li>
				</ul>
				<li><p>👋</p></li>
				</footer>
</div>
</div>

</body>  
  
</html>