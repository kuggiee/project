<?php    
$dbcon=mysqli_connect("localhost","kugen","password","project_iad");  
mysqli_select_db($dbcon,"users");  
?>  