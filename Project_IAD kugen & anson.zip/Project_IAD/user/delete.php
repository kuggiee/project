<?php 
include 'database.php';

if (isset($_POST["action"]) and $_POST["action"] == "delete") {
	$id = (isset($_POST["ci"]) ? $_POST["ci"] : '');
	$sql = "DELETE FROM courses WHERE id = $id";
	$result = mysqli_query($link, $sql);
}

header ("Location: view_user.php")
?>