<!doctype html>
<html>
<head lang="en">
<meta charset="utf-8">
<title>Project IAD</title>
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=catamaran:100,200,300.400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
	 <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css">  
</head>

<body>
<div class="header">
	<header>
		<a href="../Index.html" class="header-brand">ITEfriendly</a>
		<div class="nav">
		<nav>
			<ul>
			<li><a href="../Index.html">Home</a></li>
			<li><a href="../Course.php">Course</a></li>
			<li><a href="registration.php">Student Application</a></li>
			</ul>
			<a href="admin_login.php" class="header-login">Login</a>
			</nav>
		</div>
	</header>
	</div>
	
<div class="article">
			<section class="banner">
				<div class="vertical-center">
				<h2>ITEfriendly web developer <br>course</h2>
				<h1>Innovate Training, a continous education and training company</h1>
					</div>
				</section>   
   
  
<div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->  
    <div class="row"><!-- row class is used for grid system in Bootstrap-->  
        <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h3 class="panel-title">Registration</h3>  
                </div>  
                <div class="panel-body">  
                    <form role="form" method="post" action="registration.php">  
                        <fieldset>  
                            <div class="form-group">  
                                <input class="form-control" placeholder="Username" name="name" type="text" autofocus required>  
                            </div>  
  
                            <div class="form-group">  
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus required>  
                            </div>  
                            <div class="form-group">  
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="" required>  
                            </div>  
  
  
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="register" name="register" >  
  
                        </fieldset>  
                    </form>  
                    <center><b>Already registered ?</b> <br></b><a href="login.php">Login here</a></center><!--for centered text-->  
                </div>  
            </div>  
        </div>  
    </div>  
</div>  

	<div class="aside">
				<div class="wrapper">
				<footer>
				<ul class="list">
					<li><a href="../Course.php">Course</a></li>
					<li><a href="registration.php">Student Application</a></li>
					<li><a href="https://www.youtube.com">Youtube</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are/get-in-touch">Contact Us</a></li>
				</ul>
					<li><p>👋</p></li>
				</footer>
</div>
</div>

</body>  
  
</html>  
  
<?php  
  
include("database.php");
if(isset($_POST['register']))  
{  
    $user_name=$_POST['name'];//here getting result from the post array after submitting the form.  
    $user_pass=$_POST['pass'];//same  
    $user_email=$_POST['email'];//same  
  
  
    if($user_name=='')  
    {  
        //javascript use for input checking  
        echo"<script>alert('Please enter the name')</script>";  
exit();//this use if first is not work then other will not show  
    }  
  
    if($user_pass=='')  
    {  
        echo"<script>alert('Please enter the password')</script>";  
exit();  
    }  
  
    if($user_email=='')  
    {  
        echo"<script>alert('Please enter the email')</script>";  
    exit();  
    }  
//here query check weather if user already registered so can't register again.  
    $check_email_query="select * from users WHERE user_email='$user_email'";  
    $run_query=mysqli_query($link,$check_email_query);  
  
    if(mysqli_num_rows($run_query)>0)  
    {  
echo "<script>alert('Email $user_email is already exist in our database, Please try another one!')</script>";  
exit();  
    }  
//insert the user into the database.  
    $insert_user="insert into users (user_name,user_pass,user_email) VALUE ('$user_name','$user_pass','$user_email')";  
    if(mysqli_query($link,$insert_user))  
    {  
        echo"<script>window.open('welcome.php','_self')</script>";  
    }  
  
  
  
}  
  
?>  