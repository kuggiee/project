<?php 
include 'database.php';

if (isset($_POST["action"]) and $_POST["action"] == "delete") {
	$id = (isset($_POST["ci"]) ? $_POST["ci"] : '');
	$sql = "DELETE FROM student WHERE ID = $id";
	$sresult = mysqli_query($link, $sql);
}

header ("Location: welcome.php")
?>