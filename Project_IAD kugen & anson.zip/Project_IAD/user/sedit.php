<?php
include 'database.php';
session_start();

$sgresult = '';

if (isset($_POST['action']) and $_POST['action'] == 'edit') {
	$id = (isset($_POST["ci"]) ? $_POST["ci"] : '');
	$sql = "SELECT * FROM student WHERE id = $id";
	$sresult = mysqli_query($link, $sql);
	$sgresult = mysqli_fetch_array($sresult);
	include 'supdate.php';
	exit();
}

if (isset($_POST['action_type'])) {
	if ($_POST['action_type'] == 'add' or $_POST['action_type'] == 'edit') {
		// Sanitize the data and assign to variables
		$id = $_POST['id'];
		$name = $_POST['name'];
		$course = $_POST['course'];
		$email = $_POST['email'];
		$contact = $_POST['contact'];
		$date = $_POST['date'];
		$sEmail = $_SESSION['email'];
		
		if ($_POST['action_type'] == 'add') {
			$sql = "INSERT INTO student SET 
					name = '$name', 
					course = '$course',
					email = '$email',
					contact = '$contact', 
					date = '$date',
					username = '$sEmail'
					";
		} else {
			$sql = "UPDATE student SET 
					name = '$name', 
					course = '$course', 
					email = '$email', 
					contact = '$contact',
					date = '$date',
					username = '$sEmail'
					WHERE id = $id";
		}
		mysqli_query($link, $sql);
	}
	header ('Location: welcome.php');
	exit();
}
?>
	