<?php  
session_start();//session starts here  
  
?>  
  
  
  
<!doctype html>
<html>
<head lang="en">
<meta charset="utf-8">
<title>Project IAD</title>
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=catamaran:100,200,300.400,500,600,700,800,900|Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
	 <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css">  
</head>

<body>
<div class="header">
	<header>
		<a href="../Index.html" class="header-brand">ITEfriendly</a>
		<div class="nav">
		<nav>
			<ul>
			<li><a href="../Index.html">Home</a></li>
			<li><a href="../Course.php">Course</a></li>
			<li><a href="registration.php">Student Application</a></li>
			</ul>
			<a href="admin_login.php" class="header-login">Login</a>
			</nav>
		</div>
	</header>
	</div>
	
<div class="article">
			<section class="banner">
				<div class="vertical-center">
				<h2>ITEfriendly web developer <br>course</h2>
				<h1>Innovate Training, a continous education and training company</h1>
					</div>
				</section>   

  
<div class="container">  
    <div class="row">  
        <div class="col-md-4 col-md-offset-4">  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h3 class="panel-title">Sign In</h3>  
                </div>  
                <div class="panel-body">  
                    <form role="form" method="post" action="login.php">  
                        <fieldset>  
                            <div class="form-group"  >  
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>  
                            </div>  
                            <div class="form-group">  
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">  
                            </div>  
  
  
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" >  
  
                           
                        </fieldset>  
                    </form>  
                </div>  
            </div>  
        </div>  
    </div>  
</div>  
  <h1><a href="admin_login.php">Admin Login Here</a> </h1>
  

	<div class="aside">
				<div class="wrapper">
				<footer>
				<ul class="list">
					<li><a href="../Course.php">Course</a></li>
					<li><a href="registration.php">Student Application</a></li>
					<li><a href="https://www.youtube.com">Youtube</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="https://www.ite.edu.sg/who-we-are/get-in-touch">Contact Us</a></li>
				</ul>
				<li><p>👋</p></li>
				</footer>
</div>
</div>

</body>  
  
</html>   
  
<?php  
  
include("database.php");  
  
if(isset($_POST['login']))  
{  
    $user_email=$_POST['email'];  
    $user_pass=$_POST['pass'];
  
    $check_user="select * from users WHERE user_email='$user_email'AND user_pass='$user_pass'";  
  
    $run=mysqli_query($link,$check_user);  
  
    if(mysqli_num_rows($run))  
    {  
        echo "<script>window.open('welcome.php','_self')</script>";  
  
        $_SESSION['email']=$user_email;
  
    }  
    else  
    {  
      echo "<script>alert('Email or password is incorrect!')</script>";  
    }  
}  
?> 